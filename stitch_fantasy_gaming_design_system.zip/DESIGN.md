---
name: Obsidian Vault
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#d2c5b2'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#9a8f7e'
  outline-variant: '#4e4637'
  surface-tint: '#eec068'
  primary: '#f7c86f'
  on-primary: '#412d00'
  primary-container: '#d9ad57'
  on-primary-container: '#5c4100'
  inverse-primary: '#7b5804'
  secondary: '#bfc7d1'
  on-secondary: '#293138'
  secondary-container: '#424a52'
  on-secondary-container: '#b1b9c2'
  tertiary: '#94ddd0'
  on-tertiary: '#003731'
  tertiary-container: '#79c1b5'
  on-tertiary-container: '#004f47'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdea5'
  primary-fixed-dim: '#eec068'
  on-primary-fixed: '#271900'
  on-primary-fixed-variant: '#5d4200'
  secondary-fixed: '#dbe3ed'
  secondary-fixed-dim: '#bfc7d1'
  on-secondary-fixed: '#151c23'
  on-secondary-fixed-variant: '#40484f'
  tertiary-fixed: '#a7f0e3'
  tertiary-fixed-dim: '#8bd4c8'
  on-tertiary-fixed: '#00201c'
  on-tertiary-fixed-variant: '#005048'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  headline-xl:
    fontFamily: Newsreader
    fontSize: 38px
    fontWeight: '700'
    lineHeight: 46px
    letterSpacing: 0.02em
  headline-xl-mobile:
    fontFamily: Newsreader
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: 0.01em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: 0.01em
  headline-lg-mobile:
    fontFamily: Newsreader
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: 0.01em
  headline-md:
    fontFamily: Newsreader
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: 0.01em
  headline-sm:
    fontFamily: Newsreader
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Chivo
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0em
  body-md:
    fontFamily: Chivo
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-bold:
    fontFamily: Chivo
    fontSize: 15px
    fontWeight: '700'
    lineHeight: 22px
    letterSpacing: 0em
  label-md:
    fontFamily: Chivo
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: Chivo
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.08em
  stat-value:
    fontFamily: Chivo
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 18px
    letterSpacing: 0em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system embodies the atmosphere of an ancient, enchanted raid armory—an authoritative fusion of high-fantasy gaming grandeur (evoking titles like World of Warcraft, League of Legends, and Dota 2) with the exacting mathematical rigor of high-tier raid optimization tools. It channels the physical gravitas of a stone-cut vault lit by lantern fire, weathered bronze trim, and mystical runic inscriptions. 

The aesthetic is built on **Tactile High-Fantasy Utility**:
- **Tonal Gravitas:** Monolithic obsidian and warm charcoal slate foundations (`#121212`, `#1d2024`) replace generic flat black, providing depth without visual clutter.
- **Architectural Metalwork:** Burnished antique gold and weathered bronze trims (`#d9ad57`, `#3a3833`) structure the interface with hairline dividers, geometric diamond glyphs (`◆`), and embossed tactile focal points.
- **Runic Luminescence:** The base interface remains restrained so that mystical game semantic cues—arcane cobalt, epic amethyst, solar legendary amber, and mythic ruby—function as intense focal points with soft ambient glows.
- **Audience & Emotion:** Targeted at competitive theorycrafters, raid leaders, and dedicated RPG players who demand both epic, immersive world-building and dense, jitter-free numerical clarity. The interface feels ancient yet surgically precise.

## Colors

The palette operates in strict hierarchies to separate tactical structure from enchanted semantic signals. All base interfaces reside in a dedicated dark mode.

### Foundational Neutrals & Canvas
- **Obsidian Slab (`#121212`):** Primary canvas and input floor; keeps dense data ledgers crisp and glare-free.
- **Slate Vault Stone (`#1d2024`):** Outer viewport canvas, providing architectural depth behind primary content slabs.
- **Warm Dark Stone (`#1d1c1a`):** Surface variant for elevated cards, modal panels, and alternating table rows.
- **Burnished Charcoal (`#2a2825`):** Interactive hover state for dropdowns, list rows, and secondary clickable panels.
- **Weathered Bronze Hairline (`#3a3833`):** Low-contrast structural borders, panel dividers, and input outlines.

### Brand & Interactive Accents
- **Antique Burnished Gold (`#d9ad57`):** Primary action color, active build indicators, diamond ornaments (`◆`), focus rings, and active navigation indicators. Contrast foreground is Deep Espresso Ink (`#1a1408`).
- **Tempered Steel (`#a9b1ba`):** Secondary interactive actions, ghost button borders, and supporting controls. Contrast foreground is Dark Iron (`#121110`).
- **Arcane Seafoam Teal (`#7cc4b8`):** Tertiary accent for mystical glyph modifiers, informational callouts, and socketed passives.

### Text & Ledger Hierarchy
- **Illuminated Ivory (`#f3e7c9`):** Hero display headings, wordmarks, and legendary totals.
- **Bone-White Parchment (`#ebe3d0`):** Standard reading text, metric labels, and active inputs.
- **Aged Ash Gray (`#a39e94`):** Table column headers, passive substats, and secondary meta labels.

### Game Semantic Rarity & Progression
- **Common (`#9aa0a6`):** Forged iron gray.
- **Uncommon (`#3fb950`):** Verdant woodland green.
- **Rare (`#4c8eda`):** Arcane cobalt blue.
- **Epic (`#a371f7`):** Void amethyst purple.
- **Legendary (`#e3a008`):** Solar amber gold.
- **Mythic (`#f85149`):** Prismatic ruby crimson.
- **Delta Sage (`#84cf8a`):** Positive stat gains and completed trial milestones.
- **Delta Ember (`#ec7a63`):** Negative stat roll-offs, unmet prerequisites, and error notices.

## Typography

The typography pairings contrast cinematic storytelling with calculated tactical precision.

- **Headlines & Narrative (`Newsreader`):** A razor-sharp, authoritative serif reminiscent of carved monumental inscriptions, ancient codices, and traditional fantasy interfaces. Used for page titles, modal titles, set names, and champion epithets.
- **Body, Metrics & Ledger Data (`Chivo`):** A grotesque sans-serif with geometric discipline, high legibility at micro scales, and assertive terminal cuts. Chosen to represent tactical numbers, gear bonuses, inventory counts, and form elements.
- **Numerical Rules:** All tabular metrics, substat lists, comparison diffs, and health/mana counters must enforce `font-variant-numeric: tabular-nums lining-nums`. This prevents horizontal jittering during stat roll calculations and side-by-side ledger comparisons.
- **Micro-Labels:** Use `label-caps` in uppercase styling with generous letter spacing (`0.08em`) for rarity indicators, trial difficulties, and table column groupings.

## Layout & Spacing

The layout is built around a centralized **Stone-Framed Vault** structural model. Content lives within an obsidian slab that floats cleanly over the deeper slate-stone background.

### Layout Hierarchy & Grid
- **The Obsidian Content Slab:** Centered container constrained to a maximum width of `1440px` (`min-height: 100vh`). Surrounded by slate margins (`margin-desktop: 2.5rem`) on viewports wider than `1280px`.
- **12-Column Responsive Grid:** Used across major views, operating with a `1.5rem` gutter on desktop and reflowing to `1rem` on mobile.
- **Equipment Matrix (3×3):** High-density grids specifically formatted for 9-slot inventory gear sets (`head`, `amulet`, `shoulders`, `chest`, `gloves`, `belt`, `legs`, `boots`, `weapon`). They collapse into a 2-column or 1-column rail below `768px`.
- **Theorycrafting Split View:** A sticky two-column layout above `1024px`—left side hosts the sticky champion profile, active talent tree, and base attributes (`320px` fixed); right side hosts the fluid optimization request forms and simulation results ledger (`flex: 1`).

### Spacing Rhythm
- **Internal Density:** Strict 4px/8px micro-system (`space-xs: 0.25rem`, `space-sm: 0.5rem`, `space-md: 1rem`) preserves the compact footprint expected in raid utility spreadsheets and item matrices.
- **Macro Separation:** `space-xl` (`2.5rem`) divides unrelated ledger sections, anchored by antique gold diamond separators.

## Elevation & Depth

Visual hierarchy does not rely on bright drop shadows or heavy blur cards. Instead, it utilizes **Chiaroscuro Tonal Layering**, **Crisp Metallic Outlines**, and **Runic Glows**.

### Surface Layers
1. **Under-Vault (Base 0):** `#1d2024` (Slate Stone) provides the subterranean foundation behind the viewport edges.
2. **The Content Floor (Tier 1):** `#121212` (Obsidian Slab) separated from Tier 0 by an ultra-deep, soft ambient shadow (`box-shadow: 0 0 4rem rgba(0, 0, 0, 0.85)`).
3. **Parchment & Stone Slabs (Tier 2):** `#171615` (Warm Slate Cards) bounded by a crisp 1px weathered bronze border (`#3a3833`).
4. **Elevated Overlays & Flyouts (Tier 3):** `#1d1c1a` (Deep Charcoal Stone) bounded by a 1px antique gold rim (`#d9ad57` at 40% opacity) and an ambient occlusion shadow (`0 8px 24px rgba(0, 0, 0, 0.7)`).

### Metallic Edges & Runic Aura
- **Section Breaks:** Section titles feature a centered or trailing 1px rule crafted from a linear gradient: `rgba(217, 173, 87, 0.6)` tapering off to `transparent` on the outer edge, pinned with a miniature gold diamond (`◆`).
- **Rarity Ambient Glows:** Artifact items and champion avatars don subtle colored rim lighting according to rarity rather than standard elevation shadows:
  - *Rare:* `box-shadow: 0 0 12px rgba(76, 142, 218, 0.25)`
  - *Epic:* `box-shadow: 0 0 14px rgba(163, 113, 247, 0.3)`
  - *Legendary:* `box-shadow: 0 0 18px rgba(227, 160, 8, 0.35)`
  - *Mythic:* `box-shadow: 0 0 20px rgba(248, 81, 73, 0.4)`

## Shapes

The design system employs **Soft (`1`)** geometry. 

- **Chiseled Stone Edge:** Default interface controls, inputs, badges, and card panels feature subtle `0.25rem` (4px) rounded corners. This avoids modern hyper-rounded consumer aesthetics while maintaining sufficient softness to avoid severe brutalism.
- **Containers & Modals (`rounded-lg`):** Main item inspection modals and build drawer panels use `0.5rem` (8px).
- **Runic Gem Slugs & Form Switches (`rounded-pill`):** Reserved exclusively for rarity rank capsules, trial stage pills, and toggles to differentiate status indicators from structural stone cards.
- **Portraits & Item Sockets:** Champion avatars and inventory art slots remain rectangular or strictly square (`0.25rem` corner radius) surrounded by multi-layer metallic frames.

## Components

### Buttons & Interactive CTAs
- **Primary Forged Button (Antique Gold):** Solid burnished gold (`#d9ad57`) surface with Deep Espresso (`#1a1408`) bold text. Hover introduces a subtle radial sheen and shifts background to `#e5bd6a`. Focus state presents a 2px offset ring in `#d9ad57`.
- **Secondary Iron Button:** Dark charcoal surface (`#1d1c1a`) with a 1px weathered bronze border (`#3a3833`) and Bone-White (`#ebe3d0`) text. Hover transitions border to Tempered Steel (`#a9b1ba`) with a faint interior lift (`#2a2825`).
- **Destructive Ember Button:** Obsidian surface with a 1px crimson border (`#f85149`) and ember text (`#ec7a63`), igniting on hover with a red ambient glow (`0 0 10px rgba(248, 81, 73, 0.2)`).

### Inventory & Gear Cards
- **Gear Piece Card:** Compact slate card (`#171615`) flanked by a 1px border. Houses a 48×48px square gear thumbnail framed in the respective rarity color (e.g., Epic `#a371f7`), item level label, primary stat header, and compact key-value substat lines.
- **Equipped Status:** Inactive or unequipped pieces render at 60% opacity with 40% desaturation; equipped pieces gain full saturation and a crisp metallic border.

### Input Fields & Select Pickers
- **Text Inputs & Numerical Spinners:** Solid obsidian interior (`#121212`), 1px weathered bronze border (`#3a3833`), and Bone-White text. Numeric values default to tabular alignment.
- **Focus State:** Border shifts cleanly to `#d9ad57` accompanied by an inner hairline glow (`0 0 0 1px #d9ad57`).
- **Stat Sliders & Filters:** Obsidian trough with a burnished brass fill track and a chiseled brass diamond thumb.

### Chips & Stat Pills
- **Rarity Tier Chips:** Pill-shaped tags (`font-size: 11px`, all caps) featuring a 12% translucent fill and a solid 1px border matched to the rarity hue (e.g., Common `#9aa0a6`, Legendary `#e3a008`).
- **Trial & Target Modifiers:** Rectangular chips (`rounded: 0.25rem`) that illuminate with an emerald wash (`#84cf8a` at 15% opacity) and an emerald tick when target optimization goals are satisfied.

### Ledgers & Build Comparison Tables
- **Comparison Rows:** Monospaced tabular rows with a fixed baseline row ("Current Setup").
- **Stat Deltas:** Direct numerical diffs enclosed in compact badges: gains displayed in Sage Emerald (`#3fb950`, prefixed with `+`), losses displayed in Ember Coral (`#f85149`, prefixed with `-`).
- **Selected Build Rail:** The active simulation row features an 8% antique gold background tint and a solid 3px vertical antique gold rail along the left border.

### Checkboxes & Radios
- **Checkboxes:** Chiseled 16×16px square (`rounded: 2px`) with an obsidian background and bronze border (`#3a3833`). Checked state fills with Antique Gold (`#d9ad57`) and an espresso checkmark.
- **Radio Buttons:** Circular with a concentric gold dot indicator when active.